def calculate_sum(a,b):
result = a+b
return result

def process_data(data):
if len(data)>0:
for item in data:
print(item)
else:
print("No data")

x=5
y=10
z=calculate_sum(x,y)
print("Result:",z)