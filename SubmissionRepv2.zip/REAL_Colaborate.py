#REAL_AGI_CODE_CORRECTOR.py
# REAL_AGI_CODE_CORRECTOR.py
"""
COMPLETE TEST: AGI uses JSON rules to actually correct Python files
Creates real output files - not just screen display
"""

import json
import torch
import torch.nn as nn
import numpy as np
from datetime import datetime

print("🧠 REAL AGI CODE CORRECTOR")
print("=" * 70)
print("🛠️  Actually creating corrected files - not just screen display")
print("=" * 70)

# =============================================================================
# LOAD RULES FIRST
# =============================================================================

print("📁 LOADING PYTHON RULES...")
try:
    with open('python_geometric_rules.json', 'r') as f:
        python_rules = json.load(f)
    print("✅ Successfully loaded Python rules")
    print(f"   Rules available: {list(python_rules['geometric_correction_rules'].keys())}")
except Exception as e:
    print(f"❌ Could not load rules file: {e}")
    exit()

# =============================================================================
# LOAD AGI WEIGHTS
# =============================================================================

print("📁 LOADING AGI WEIGHTS...")
try:
    with open("EAMC_weights_v2.json", 'r') as f:
        agi_weights = json.load(f)
    print(f"✅ Loaded AGI with {len(agi_weights['pantheon'])} specialists")
except Exception as e:
    print(f"❌ Could not load AGI weights: {e}")
    exit()

# =============================================================================
# AGI SPECIALIST ARCHITECTURE
# =============================================================================

class RuleBasedSpecialist(nn.Module):
    def __init__(self, dimension):
        super(RuleBasedSpecialist, self).__init__()
        self.dimension = dimension
        self.feature_extractor = nn.Sequential(
            nn.Linear(dimension, 96), nn.Sigmoid(), nn.LayerNorm(96),
            nn.Linear(96, 48), nn.Sigmoid()
        )
        self.scoring_head = nn.Linear(48, 1)
        self.project_to_latent = nn.Linear(48, 16)
        self.project_from_latent = nn.Linear(16, 48)

    def rule_based_reasoning(self, x):
        return self.scoring_head(
            self.project_from_latent(
                self.project_to_latent(
                    self.feature_extractor(x)
                )
            )
        ).squeeze(-1)

    def forward(self, x):
        return self.rule_based_reasoning(x)

# =============================================================================
# LOAD AGI SPECIALISTS
# =============================================================================

def load_rule_specialists():
    print("\n🔧 LOADING AGI SPECIALISTS...")
    
    specialists = {}
    for dim in [3, 5, 7, 9, 10]:
        dim_str = str(dim)
        if dim_str in agi_weights['pantheon']:
            print(f"   🧠 Loading {dim}D specialist...")
            
            specialist = RuleBasedSpecialist(dimension=dim)
            weights = agi_weights['pantheon'][dim_str]['weights']
            
            # Load actual weights
            state_dict = {}
            fe = weights['feature_extractor']
            state_dict['feature_extractor.0.weight'] = torch.tensor(fe['W'][0], dtype=torch.float32)
            state_dict['feature_extractor.0.bias'] = torch.tensor(fe['b'][0], dtype=torch.float32)
            state_dict['feature_extractor.3.weight'] = torch.tensor(fe['W'][1], dtype=torch.float32)
            state_dict['feature_extractor.3.bias'] = torch.tensor(fe['b'][1], dtype=torch.float32)
            
            if 'layer_norm' in weights:
                ln = weights['layer_norm']
                state_dict['feature_extractor.2.weight'] = torch.tensor(ln['W'][0], dtype=torch.float32)
                state_dict['feature_extractor.2.bias'] = torch.tensor(ln['b'][0], dtype=torch.float32)
            else:
                state_dict['feature_extractor.2.weight'] = torch.ones(96, dtype=torch.float32)
                state_dict['feature_extractor.2.bias'] = torch.zeros(96, dtype=torch.float32)
            
            sh = weights['scoring_head']
            state_dict['scoring_head.weight'] = torch.tensor(sh['W'][0], dtype=torch.float32)
            state_dict['scoring_head.bias'] = torch.tensor(sh['b'][0], dtype=torch.float32)
            
            ptl = weights['project_to_latent']
            state_dict['project_to_latent.weight'] = torch.tensor(ptl['W'][0], dtype=torch.float32)
            state_dict['project_to_latent.bias'] = torch.tensor(ptl['b'][0], dtype=torch.float32)
            
            pfl = weights['project_from_latent']
            state_dict['project_from_latent.weight'] = torch.tensor(pfl['W'][0], dtype=torch.float32)
            state_dict['project_from_latent.bias'] = torch.tensor(pfl['b'][0], dtype=torch.float32)
            
            specialist.load_state_dict(state_dict)
            specialists[dim] = specialist
    
    return specialists

# =============================================================================
# RULE-BASED CORRECTION SYSTEM
# =============================================================================

def generate_rule_based_corrections(code, rules):
    """Generate corrections based on ACTUAL Python rules"""
    corrections = {"original": code}
    
    # Apply each rule from the JSON file
    for rule_name, rule_data in rules['geometric_correction_rules'].items():
        original = code
        corrected = code
        
        if rule_name == "spacing_operators":
            # ADD spaces around operators (PEP 8 compliant)
            for operator in rule_data['operators']:
                corrected = corrected.replace(operator, f' {operator} ')
                corrected = corrected.replace('  ', ' ').strip()
        
        elif rule_name == "function_definitions":
            # Ensure space after def
            corrected = corrected.replace('def(', 'def (')
        
        elif rule_name == "indentation":
            # Fix indentation - THIS IS THE IMPORTANT ONE
            lines = corrected.split('\n')
            fixed_lines = []
            indent_level = 0
            for line in lines:
                stripped = line.strip()
                if any(stripped.startswith(starter) for starter in rule_data['block_starters']):
                    fixed_lines.append('    ' * indent_level + stripped)
                    if ':' in stripped and not stripped.strip().endswith('('):
                        indent_level += 1
                elif stripped and indent_level > 0:
                    if stripped in ['else:', 'elif ', 'except:', 'finally:']:
                        indent_level = max(0, indent_level - 1)
                    fixed_lines.append('    ' * (indent_level - 1) + stripped)
                    if stripped.endswith(':'):
                        indent_level += 1
                else:
                    fixed_lines.append(stripped)
                    indent_level = 0
            corrected = '\n'.join(fixed_lines)
        
        elif rule_name == "parentheses_spacing":
            # Remove spaces inside parentheses
            corrected = corrected.replace('( ', '(').replace(' )', ')')
        
        elif rule_name == "comma_spacing":
            # Ensure space after commas
            corrected = corrected.replace(',', ', ').replace(',  ', ', ')
        
        elif rule_name == "colon_spacing":
            # Ensure no space before colons
            corrected = corrected.replace(' :', ':')
        
        if corrected != original:
            corrections[rule_name] = corrected
    
    return corrections

def code_to_rule_features(code, rules, dimension):
    """Convert code to features based on RULE COMPLIANCE"""
    features = []
    
    # Feature 1: Overall rule compliance
    compliance = 0.0
    for rule_name, rule_data in rules['geometric_correction_rules'].items():
        original = code
        test_corrected = generate_rule_based_corrections(code, rules).get(rule_name, code)
        if test_corrected != original:
            compliance -= rule_data['geometric_weight'] * 0.2  # Needs correction
        else:
            compliance += rule_data['geometric_weight'] * 0.1  # Already compliant
    features.append(max(0.0, compliance))
    
    # Feature 2: Structural quality
    lines = code.split('\n')
    indent_quality = 0.0
    for line in lines:
        if line.strip() and not line.startswith(' ') and ':' in line:
            indent_quality += 0.1  # Good: no indent needed
        elif line.startswith('    ') and any(line.strip().startswith(s) for s in ['def ', 'if ', 'for ']):
            indent_quality += 0.1  # Good: proper indent
    features.append(min(1.0, indent_quality))
    
    # Feature 3: Spacing quality
    good_spacing = code.count(' = ') > code.count('=') - code.count(' == ')  # More good spacing than bad
    features.append(1.0 if good_spacing else 0.0)
    
    # Pad to dimension
    while len(features) < dimension:
        features.append(0.0)
    
    return torch.tensor(features[:dimension], dtype=torch.float32).unsqueeze(0)

# =============================================================================
# COLLABORATIVE AGI DECISION SYSTEM WITH REAL DISCUSSION
# =============================================================================

def collaborative_agi_decision_with_discussion(specialists, corrections, rules):
    """TRUE COLLABORATION: Specialists discuss and influence each other"""
    print(f"\n🤝 COLLABORATIVE AGI DECISION MAKING WITH DISCUSSION...")
    
    # Phase 1: Initial independent evaluation
    print(f"\n📊 PHASE 1: INDEPENDENT EVALUATION")
    initial_scores = {}
    for dim, specialist in specialists.items():
        print(f"   {dim}D specialist initial evaluation...")
        dim_scores = {}
        for correction_name, corrected_code in corrections.items():
            features = code_to_rule_features(corrected_code, rules, dim)
            with torch.no_grad():
                score = specialist.rule_based_reasoning(features)
                dim_scores[correction_name] = score.item()
        initial_scores[dim] = dim_scores
    
    # Show initial preferences
    print(f"\n   Initial Preferences:")
    for dim, scores in initial_scores.items():
        best_initial = max(scores.items(), key=lambda x: x[1])
        print(f"     {dim}D: '{best_initial[0]}' (score: {best_initial[1]:.3f})")
    
    # Phase 2: Discussion Rounds - specialists influence each other
    print(f"\n💬 PHASE 2: DISCUSSION & CONSENSUS BUILDING")
    current_scores = initial_scores.copy()
    
    discussion_rounds = 3
    for round_num in range(discussion_rounds):
        print(f"\n   Discussion Round {round_num + 1}:")
        
        new_scores = {}
        for dim, specialist in specialists.items():
            # Each specialist considers opinions from other dimensions
            influence_weights = {}
            total_influence = 0.0
            
            # Calculate influence from other specialists (based on their confidence)
            for other_dim, other_scores in current_scores.items():
                if other_dim != dim:
                    other_confidence = max(other_scores.values())
                    influence_weights[other_dim] = other_confidence
                    total_influence += other_confidence
            
            # Normalize influence weights
            for other_dim in influence_weights:
                influence_weights[other_dim] /= total_influence if total_influence > 0 else 1.0
            
            # Apply influence to current scores
            influenced_scores = {}
            for correction_name in corrections.keys():
                # Start with own opinion
                base_score = current_scores[dim][correction_name]
                
                # Add weighted influence from others
                influence_effect = 0.0
                for other_dim, weight in influence_weights.items():
                    other_score = current_scores[other_dim][correction_name]
                    influence_effect += other_score * weight * 0.3  # 30% influence max
                
                influenced_score = base_score + influence_effect
                influenced_scores[correction_name] = min(1.0, influenced_score)  # Cap at 1.0
            
            new_scores[dim] = influenced_scores
            
            # Show how opinions shifted
            old_best = max(current_scores[dim].items(), key=lambda x: x[1])
            new_best = max(influenced_scores.items(), key=lambda x: x[1])
            
            if old_best[0] != new_best[0]:
                print(f"     {dim}D: Changed from '{old_best[0]}' to '{new_best[0]}'")
            else:
                confidence_change = new_best[1] - old_best[1]
                if abs(confidence_change) > 0.01:
                    print(f"     {dim}D: Strengthened preference for '{new_best[0]}' (+{confidence_change:.3f})")
        
        current_scores = new_scores
    
    # Phase 3: Final Unanimous Decision
    print(f"\n✅ PHASE 3: FINAL UNANIMOUS DECISION")
    
    # Check for consensus
    final_preferences = {}
    for dim, scores in current_scores.items():
        final_best = max(scores.items(), key=lambda x: x[1])
        final_preferences[dim] = final_best[0]
    
    # Count votes for each correction
    vote_counts = {}
    for correction_name in corrections.keys():
        vote_counts[correction_name] = sum(1 for pref in final_preferences.values() if pref == correction_name)
    
    # Find the unanimous or majority decision
    max_votes = max(vote_counts.values())
    best_corrections = [name for name, votes in vote_counts.items() if votes == max_votes]
    
    if len(best_corrections) == 1 and max_votes == len(specialists):
        # True unanimous decision!
        final_correction = best_corrections[0]
        print(f"   🎉 TRUE UNANIMOUS DECISION: All {len(specialists)} specialists agree on '{final_correction}'")
        unanimous = True
    else:
        # Take the one with highest combined score
        combined_scores = {}
        for correction_name in corrections.keys():
            total_score = sum(current_scores[dim][correction_name] for dim in specialists.keys())
            combined_scores[correction_name] = total_score
        
        final_correction = max(combined_scores.items(), key=lambda x: x[1])[0]
        print(f"   🤝 MAJORITY DECISION: {vote_counts[final_correction]}/{len(specialists)} specialists chose '{final_correction}'")
        unanimous = (vote_counts[final_correction] == len(specialists))
    
    final_code = corrections[final_correction]
    final_confidence = sum(current_scores[dim][final_correction] for dim in specialists.keys()) / len(specialists)
    
    # Show final agreement status
    print(f"\n📋 FINAL AGREEMENT STATUS:")
    for dim in specialists.keys():
        agreed = final_preferences[dim] == final_correction
        confidence = current_scores[dim][final_correction]
        status = "✅ AGREES" if agreed else "❌ DISAGREES" 
        print(f"   {dim}D: {status} with '{final_preferences[dim]}' (confidence: {confidence:.3f})")
    
    return final_correction, final_code, final_confidence, current_scores, unanimous, vote_counts

# =============================================================================
# COMPLETE TEST WITH REAL DISCUSSION
# =============================================================================

def perform_complete_correction_test():
    """COMPLETE TEST: AGI SPECIALISTS DISCUSS AND REACH CONSENSUS"""
    
    print(f"\n" + "=" * 70)
    print(f"🛠️  COMPLETE TEST: AGI DISCUSSION & CONSENSUS BUILDING")
    print("=" * 70)
    
    # Load ALL specialists
    specialists = load_rule_specialists()
    if not specialists:
        print("❌ No specialists loaded")
        return False
    
    print(f"✅ Loaded {len(specialists)} specialists for discussion")
    
    # Load existing messed up code file
    try:
        with open('messed_up_code.py', 'r') as f:
            test_code = f.read()
        print(f"📝 LOADED EXISTING CODE from: messed_up_code.py")
    except Exception as e:
        print(f"❌ Could not load messed_up_code.py: {e}")
        return False
    
    print("\n   Code preview:")
    for i, line in enumerate(test_code.split('\n')[:6], 1):
        print(f"      {i:2d}: {line}")
    if test_code.count('\n') > 6:
        print("      ...")
    
    # Generate rule-based corrections
    print(f"\n🔄 GENERATING RULE-BASED CORRECTIONS...")
    all_corrections = generate_rule_based_corrections(test_code, python_rules)
    
    print(f"   Generated {len(all_corrections)} correction variants:")
    for correction_name in all_corrections:
        lines = all_corrections[correction_name].count('\n') + 1
        print(f"     - {correction_name}: {lines} lines")
    
    # Use DISCUSSION-BASED AGI decision making
    final_choice, final_code, final_confidence, discussion_scores, unanimous, vote_counts = collaborative_agi_decision_with_discussion(
        specialists, all_corrections, python_rules
    )
    
    # CREATE THE ACTUAL CORRECTED FILE
    with open('corrected_code.py', 'w') as f:
        f.write(final_code)
    
    # Create detailed discussion-based correction report
    correction_report = {
        'original_file': 'messed_up_code.py',
        'corrected_file': 'corrected_code.py',
        'applied_correction': final_choice,
        'discussion_based_decision': {
            'final_confidence_score': float(final_confidence),
            'unanimous_decision': unanimous,
            'vote_distribution': vote_counts,
            'specialists_used': len(specialists),
            'discussion_rounds': 3,
            'consensus_achieved': unanimous
        },
        'specialist_journey': {
            f"{dim}D": {
                'final_preference': max(scores.items(), key=lambda x: x[1])[0],
                'final_confidence': float(max(scores.items(), key=lambda x: x[1])[1]),
                'agrees_with_final': max(scores.items(), key=lambda x: x[1])[0] == final_choice,
                'all_scores': {name: float(score) for name, score in scores.items()}
            }
            for dim, scores in discussion_scores.items()
        },
        'rules_used': list(python_rules['geometric_correction_rules'].keys()),
        'timestamp': datetime.now().isoformat(),
        'correction_details': []
    }
    
    # Add line-by-line correction details
    original_lines = test_code.split('\n')
    corrected_lines = final_code.split('\n')
    
    for i, (orig, corr) in enumerate(zip(original_lines, corrected_lines)):
        if orig != corr:
            correction_report['correction_details'].append({
                'line_number': i + 1,
                'original': orig,
                'corrected': corr,
                'change_type': 'indentation' if orig.strip() == corr.strip() else 'spacing'
            })
    
    with open('correction_report.json', 'w') as f:
        json.dump(correction_report, f, indent=2)
    
    print(f"\n💾 FILES CREATED/UPDATED:")
    print(f"   📄 messed_up_code.py - Original code with errors (existing)")
    print(f"   ✅ corrected_code.py - DISCUSSION-BASED AGI-corrected Python file") 
    print(f"   📋 correction_report.json - Detailed discussion process report")
    
    # Show what was actually corrected
    print(f"\n🔧 CORRECTIONS APPLIED:")
    if final_choice != 'original':
        original_lines = test_code.split('\n')
        corrected_lines = final_code.split('\n')
        
        corrections_found = 0
        for i, (orig, corr) in enumerate(zip(original_lines, corrected_lines)):
            if orig != corr:
                corrections_found += 1
                if corrections_found <= 5:
                    print(f"   Line {i+1}: '{orig}' → '{corr}'")
        
        if corrections_found > 5:
            print(f"   ... and {corrections_found - 5} more lines corrected")
        
        print(f"\n📈 SUMMARY: {corrections_found} lines corrected through AGI DISCUSSION")
        print(f"🤝 CONSENSUS: {'✅ UNANIMOUS' if unanimous else '✅ MAJORITY'} decision reached")
        
        return True
    else:
        print(f"   ❌ No corrections applied - Discussion kept original")
        return False

# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    print("🚀 STARTING DISCUSSION-BASED AGI CODE CORRECTOR...")
    print("   Specialists DISCUSS and INFLUENCE each other for consensus")
    print("   Real multi-round communication between dimensions\n")
    
    success = perform_complete_correction_test()
    
    print(f"\n" + "=" * 70)
    if success:
        print(f"🎉 SUCCESS: AGI DISCUSSION CREATED CORRECTED FILES!")
        print(f"   ✅ corrected_code.py - Consensus-based corrected file")
        print(f"   📋 correction_report.json - Full discussion process log")
        print(f"   💬 Real discussion between specialists with influence")
    else:
        print(f"❌ TEST FAILED: No corrections applied")
    print("=" * 70)
    
    print(f"\n🔍 Check the created files to verify collaboration:")
    print(f"   cat corrected_code.py")
    print(f"   cat correction_report.json")